import { BadRequestException, ConflictException, Injectable, NotFoundException } from "@nestjs/common";
import { AppliesTo, Prisma, RecordStatus } from "@prisma/client";
import { ComplianceService } from "../compliance/compliance.service";
import { PrismaService } from "../prisma/prisma.service";
import { CreateProductDto } from "./dto/create-product.dto";
import { CreateVariantDto } from "./dto/create-variant.dto";
import { UpdateProductDto } from "./dto/update-product.dto";
import { UpdateVariantDto } from "./dto/update-variant.dto";

@Injectable()
export class CatalogService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly complianceService: ComplianceService,
  ) {}

  async stats() {
    const [categories, products, variants] = await Promise.all([
      this.prisma.tenant().category.count(),
      this.prisma.tenant().product.count(),
      this.prisma.tenant().variant.count(),
    ]);
    return { categories, products, variants };
  }

  async listProducts() {
    const products = await this.prisma.tenant().product.findMany({
      include: {
        category: true,
        variants: true,
        validationIssues: { where: { status: "open" } },
      },
      orderBy: [{ updatedAt: "desc" }],
    });
    return this.attachCompletenessScores(products);
  }

  async getProduct(productId: string) {
    const product = await this.prisma.tenant().product.findUnique({
      where: { id: productId },
      include: {
        category: true,
        variants: { orderBy: [{ updatedAt: "desc" }] },
        validationIssues: { where: { status: "open" }, orderBy: [{ createdAt: "desc" }] },
      },
    });
    if (!product) {
      throw new NotFoundException("Product not found");
    }
    const [withScore] = await this.attachCompletenessScores([product]);
    return withScore;
  }

  async createProduct(dto: CreateProductDto) {
    await this.requireCategory(dto.categoryId);
    const product = await this.prisma.tenant().product.create({
      data: {
        title: dto.title.trim(),
        description: dto.description.trim(),
        brand: dto.brand.trim(),
        categoryId: dto.categoryId,
        hsnCode: dto.hsnCode?.trim() || null,
        gstRate: dto.gstRate ?? null,
        attributes: (dto.attributes ?? {}) as Prisma.JsonObject,
        status: dto.status as RecordStatus,
      },
      include: { category: true, variants: true },
    });
    await this.complianceService.validateAndPersistProduct(product.id);
    return product;
  }

  async updateProduct(productId: string, dto: UpdateProductDto) {
    const current = await this.requireProduct(productId);
    if (dto.expectedVersion !== current.version) {
      this.throwVersionConflict(dto.expectedVersion, current.version);
    }
    await this.requireCategory(dto.categoryId);
    const updateResult = await this.prisma.tenant().product.updateMany({
      where: {
        id: productId,
        version: dto.expectedVersion,
      },
      data: {
        title: dto.title.trim(),
        description: dto.description.trim(),
        brand: dto.brand.trim(),
        categoryId: dto.categoryId,
        hsnCode: dto.hsnCode?.trim() || null,
        gstRate: dto.gstRate ?? null,
        attributes: (dto.attributes ?? {}) as Prisma.JsonObject,
        status: dto.status as RecordStatus,
        version: { increment: 1 },
      },
    });
    if (updateResult.count === 0) {
      const latest = await this.requireProduct(productId);
      this.throwVersionConflict(dto.expectedVersion, latest.version);
    }
    const product = await this.prisma.tenant().product.findUniqueOrThrow({
      where: { id: productId },
      include: { category: true, variants: true },
    });
    await this.complianceService.validateAndPersistProduct(product.id);
    return product;
  }

  async deleteProduct(productId: string) {
    await this.requireProduct(productId);
    await this.prisma.tenant().product.delete({ where: { id: productId } });
  }

  async listVariants(productId: string) {
    await this.requireProduct(productId);
    return this.prisma.tenant().variant.findMany({
      where: { productId },
      orderBy: [{ updatedAt: "desc" }],
    });
  }

  async createVariant(productId: string, dto: CreateVariantDto) {
    await this.requireProduct(productId);
    this.validatePricing(dto.mrp, dto.sellingPrice);
    try {
      return await this.prisma.tenant().variant.create({
        data: {
          productId,
          skuCode: dto.skuCode.trim(),
          attributes: dto.attributes as Prisma.JsonObject,
          mrp: dto.mrp ?? null,
          sellingPrice: dto.sellingPrice ?? null,
          inventoryQty: dto.inventoryQty,
          status: dto.status as RecordStatus,
        },
      });
    } catch (error: unknown) {
      if (error instanceof Prisma.PrismaClientKnownRequestError && error.code === "P2002") {
        throw new BadRequestException("SKU code already exists");
      }
      throw error;
    }
  }

  async updateVariant(variantId: string, dto: UpdateVariantDto) {
    await this.requireVariant(variantId);
    this.validatePricing(dto.mrp, dto.sellingPrice);
    try {
      return await this.prisma.tenant().variant.update({
        where: { id: variantId },
        data: {
          skuCode: dto.skuCode.trim(),
          attributes: dto.attributes as Prisma.JsonObject,
          mrp: dto.mrp ?? null,
          sellingPrice: dto.sellingPrice ?? null,
          inventoryQty: dto.inventoryQty,
          status: dto.status as RecordStatus,
        },
      });
    } catch (error: unknown) {
      if (error instanceof Prisma.PrismaClientKnownRequestError && error.code === "P2002") {
        throw new BadRequestException("SKU code already exists");
      }
      throw error;
    }
  }

  async deleteVariant(variantId: string) {
    await this.requireVariant(variantId);
    await this.prisma.tenant().variant.delete({ where: { id: variantId } });
  }

  private async requireCategory(categoryId: string) {
    const category = await this.prisma.tenant().category.findUnique({ where: { id: categoryId } });
    if (!category) {
      throw new NotFoundException("Category not found");
    }
    return category;
  }

  private async requireProduct(productId: string) {
    const product = await this.prisma.tenant().product.findUnique({ where: { id: productId } });
    if (!product) {
      throw new NotFoundException("Product not found");
    }
    return product;
  }

  private async requireVariant(variantId: string) {
    const variant = await this.prisma.tenant().variant.findUnique({ where: { id: variantId } });
    if (!variant) {
      throw new NotFoundException("Variant not found");
    }
    return variant;
  }

  private validatePricing(mrp?: number, sellingPrice?: number) {
    if (mrp !== undefined && sellingPrice !== undefined && sellingPrice > mrp) {
      throw new BadRequestException("Selling price cannot exceed MRP");
    }
  }

  private throwVersionConflict(expectedVersion: number, currentVersion: number): never {
    throw new ConflictException({
      code: "VERSION_CONFLICT",
      message: "Product has been updated by another operation. Reload and retry.",
      expectedVersion,
      currentVersion,
    });
  }

  private async attachCompletenessScores<
    T extends {
      categoryId: string;
      title: string;
      brand: string;
      description: string;
      hsnCode: string | null;
      gstRate: number | null;
      attributes: unknown;
    },
  >(products: T[]) {
    if (products.length === 0) {
      return products;
    }

    const categoryIds = Array.from(new Set(products.map((product) => product.categoryId)));
    const requiredAttributes = await this.prisma.tenant().attributeDefinition.findMany({
      where: {
        categoryId: { in: categoryIds },
        appliesTo: AppliesTo.product,
        required: true,
      },
      select: {
        categoryId: true,
        key: true,
      },
    });

    const requiredByCategory = new Map<string, string[]>();
    for (const attribute of requiredAttributes) {
      const existing = requiredByCategory.get(attribute.categoryId) ?? [];
      existing.push(attribute.key);
      requiredByCategory.set(attribute.categoryId, existing);
    }

    return products.map((product) => ({
      ...product,
      completenessScore: this.calculateCompletenessScore(
        product,
        requiredByCategory.get(product.categoryId) ?? [],
      ),
    }));
  }

  private calculateCompletenessScore(
    product: {
      title: string;
      brand: string;
      description: string;
      hsnCode: string | null;
      gstRate: number | null;
      attributes: unknown;
    },
    requiredAttributeKeys: string[],
  ) {
    const coreValues = [product.title, product.brand, product.description, product.hsnCode, product.gstRate];
    const filledCore = coreValues.filter((value) => !this.isEmpty(value)).length;
    const requiredTotal = coreValues.length + requiredAttributeKeys.length;

    if (requiredTotal === 0) {
      return 100;
    }

    const attributes = this.asRecord(product.attributes);
    const filledAttributes = requiredAttributeKeys.filter((key) => !this.isEmpty(attributes[key])).length;
    return Math.round(((filledCore + filledAttributes) / requiredTotal) * 100);
  }

  private asRecord(value: unknown): Record<string, unknown> {
    if (value && typeof value === "object" && !Array.isArray(value)) {
      return value as Record<string, unknown>;
    }
    return {};
  }

  private isEmpty(value: unknown) {
    return value === null || value === undefined || (typeof value === "string" && value.trim() === "");
  }
}
