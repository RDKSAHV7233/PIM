import { ValidationPipe } from "@nestjs/common";
import { NestFactory } from "@nestjs/core";
import { FastifyAdapter, NestFastifyApplication } from "@nestjs/platform-fastify";
import { IncomingMessage, ServerResponse } from "node:http";
import { AppModule } from "./app.module";
import { runWithTenantContext } from "./common/tenant/tenant-context";
import { normalizeTenantKey, TENANT_HEADER } from "./common/tenant/tenant.constants";

const FASTIFY_BODY_LIMIT_BYTES = 10 * 1024 * 1024;

async function bootstrap() {
  const app = await NestFactory.create<NestFastifyApplication>(
    AppModule,
    new FastifyAdapter({
      bodyLimit: FASTIFY_BODY_LIMIT_BYTES,
    }),
  );

  app.setGlobalPrefix("api");
  app.enableCors({
    origin: true,
    credentials: true,
  });
  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,
      transform: true,
      forbidUnknownValues: false,
    }),
  );

  app.use((req: IncomingMessage, _res: ServerResponse, next: () => void) => {
    const headerValue = req.headers[TENANT_HEADER];
    const tenantHeader = Array.isArray(headerValue) ? headerValue[0] : headerValue;
    runWithTenantContext(normalizeTenantKey(tenantHeader), next);
  });

  const port = Number(process.env.PORT ?? 4000);
  await app.listen(port, "0.0.0.0");
  // eslint-disable-next-line no-console
  console.log(`API running on http://localhost:${port}/api`);
}

bootstrap();
