import { Injectable, OnModuleDestroy, OnModuleInit } from "@nestjs/common";
import { PrismaClient } from "@prisma/client";
import { getTenantKeyFromContext } from "../common/tenant/tenant-context";
import { normalizeTenantKey } from "../common/tenant/tenant.constants";

function withTenantDatabaseUrl(databaseUrl: string, tenantKey: string): string {
  const encoded = encodeURIComponent(`-c app.tenant_key=${tenantKey}`);
  if (databaseUrl.includes("options=")) {
    return databaseUrl.replace(/([?&])options=[^&]*/, `$1options=${encoded}`);
  }
  if (databaseUrl.includes("?")) {
    return `${databaseUrl}&options=${encoded}`;
  }
  return `${databaseUrl}?options=${encoded}`;
}

@Injectable()
export class PrismaService implements OnModuleInit, OnModuleDestroy {
  private readonly clients = new Map<string, PrismaClient>();

  private getBaseDatabaseUrl(): string {
    const databaseUrl = String(process.env.DATABASE_URL ?? "").trim();
    if (!databaseUrl) {
      throw new Error("DATABASE_URL is not configured.");
    }
    return databaseUrl;
  }

  private createClient(tenantKey: string): PrismaClient {
    const datasourceUrl = withTenantDatabaseUrl(this.getBaseDatabaseUrl(), tenantKey);
    return new PrismaClient({
      datasources: {
        db: {
          url: datasourceUrl,
        },
      },
    });
  }

  private getClient(tenantKey: string): PrismaClient {
    const normalizedTenant = normalizeTenantKey(tenantKey);
    const existing = this.clients.get(normalizedTenant);
    if (existing) {
      return existing;
    }
    const created = this.createClient(normalizedTenant);
    this.clients.set(normalizedTenant, created);
    return created;
  }

  tenant(tenantKey?: string): PrismaClient {
    const effectiveTenant = normalizeTenantKey(tenantKey ?? getTenantKeyFromContext());
    return this.getClient(effectiveTenant);
  }

  async onModuleInit() {
    await this.tenant().$connect();
  }

  async onModuleDestroy() {
    const clients = Array.from(this.clients.values());
    this.clients.clear();
    await Promise.all(clients.map((client) => client.$disconnect()));
  }
}
