$ErrorActionPreference = "Stop"

function Set-SmokeTenantDatabaseUrl {
  param(
    [string]$TenantKey = $env:PIM_SMOKE_TENANT_KEY
  )

  $databaseUrl = [System.Environment]::GetEnvironmentVariable("DATABASE_URL", "Process")
  if ([string]::IsNullOrWhiteSpace($databaseUrl)) {
    return
  }

  $effectiveTenantKey = if ([string]::IsNullOrWhiteSpace($TenantKey)) {
    "smoke-tenant"
  } else {
    $TenantKey.Trim()
  }

  $optionValue = [System.Uri]::EscapeDataString("-c app.tenant_key=$effectiveTenantKey")
  $withTenant = if ($databaseUrl -match "(^|[?&])options=") {
    [System.Text.RegularExpressions.Regex]::Replace(
      $databaseUrl,
      "([?&])options=[^&]*",
      ('$1options=' + $optionValue),
      1
    )
  } elseif ($databaseUrl.Contains("?")) {
    "$databaseUrl&options=$optionValue"
  } else {
    "$databaseUrl?options=$optionValue"
  }

  [System.Environment]::SetEnvironmentVariable("DATABASE_URL", $withTenant, "Process")
  [System.Environment]::SetEnvironmentVariable("PIM_SMOKE_TENANT_KEY", $effectiveTenantKey, "Process")
  [System.Environment]::SetEnvironmentVariable("PIM_DEFAULT_TENANT_KEY", $effectiveTenantKey, "Process")
}
