#!/usr/bin/env node
/* eslint-disable no-console */
const { PrismaClient } = require("@prisma/client");
const CHECKER_ROLE = "pim1_rls_checker";

function withTenant(databaseUrl, tenantKey) {
  const encoded = encodeURIComponent(`-c app.tenant_key=${tenantKey}`);
  if (databaseUrl.includes("options=")) {
    return databaseUrl.replace(/([?&])options=[^&]*/, `$1options=${encoded}`);
  }
  if (databaseUrl.includes("?")) {
    return `${databaseUrl}&options=${encoded}`;
  }
  return `${databaseUrl}?options=${encoded}`;
}

async function run() {
  const baseUrl = process.env.DATABASE_URL;
  if (!baseUrl) {
    throw new Error("DATABASE_URL is required in environment.");
  }

  const defaultClient = new PrismaClient({
    datasources: {
      db: { url: withTenant(baseUrl, "default") },
    },
  });
  const smokeClient = new PrismaClient({
    datasources: {
      db: { url: withTenant(baseUrl, "smoke-tenant") },
    },
  });

  const timestamp = Date.now();
  const categoryName = `Smoke Isolation ${timestamp}`;
  let createdId = null;

  try {
    await defaultClient.$executeRawUnsafe(`
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = '${CHECKER_ROLE}') THEN
    EXECUTE 'CREATE ROLE ${CHECKER_ROLE} NOLOGIN NOBYPASSRLS';
  END IF;
END $$;
    `);
    await defaultClient.$executeRawUnsafe(
      `GRANT USAGE ON SCHEMA public TO ${CHECKER_ROLE}`,
    );
    await defaultClient.$executeRawUnsafe(
      `GRANT SELECT ON TABLE "Category" TO ${CHECKER_ROLE}`,
    );

    const created = await smokeClient.category.create({
      data: {
        name: categoryName,
        slug: `smoke-isolation-${timestamp}`,
        path: categoryName,
      },
      select: { id: true },
    });
    createdId = created.id;

    const [defaultVisibleRows, smokeVisibleRows] = await Promise.all([
      defaultClient.$transaction(async (tx) => {
        await tx.$executeRawUnsafe(`SET LOCAL ROLE ${CHECKER_ROLE}`);
        return tx.$queryRawUnsafe(
          `SELECT COUNT(*)::INT AS count FROM "Category" WHERE id = $1`,
          createdId,
        );
      }),
      smokeClient.$transaction(async (tx) => {
        await tx.$executeRawUnsafe(`SET LOCAL ROLE ${CHECKER_ROLE}`);
        return tx.$queryRawUnsafe(
          `SELECT COUNT(*)::INT AS count FROM "Category" WHERE id = $1`,
          createdId,
        );
      }),
    ]);

    const defaultVisible = defaultVisibleRows[0]?.count ?? 0;
    const smokeVisible = smokeVisibleRows[0]?.count ?? 0;

    const result = {
      categoryId: createdId,
      defaultVisible,
      smokeVisible,
      isolated: defaultVisible === 0 && smokeVisible === 1,
      checkedAt: new Date().toISOString(),
    };

    console.log(JSON.stringify(result, null, 2));
    if (!result.isolated) {
      process.exitCode = 1;
    }
  } finally {
    if (createdId) {
      await smokeClient.category.deleteMany({ where: { id: createdId } });
    }
    await Promise.all([defaultClient.$disconnect(), smokeClient.$disconnect()]);
  }
}

run().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
